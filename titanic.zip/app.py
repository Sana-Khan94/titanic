from flask import Flask, render_template, request,jsonify
from flask import Response
from flask_cors import cross_origin
import pickle
import pandas as pd

app = Flask(__name__)



@app.route("/titanic_via_postman",method=['POST'])
@cross_origin()
def predictRoute():
    try:
        if request.json['data'] is not None:
            data = request.json['data']
            print('data is:     ', data)
            res = predict_lr(data)
            print('result is        ',res)
            return Response(res)
    except ValueError:
        return Response("Value not found")
    except Exception as e:
        print('exception is   ',e)
        return Response(e)



def predict_lr(dict_pred):
    if (request.method=='POST'):
        with open('titanic_lr_mode.pickle','rb') as f:
            model = pickle.load(f)

        data_df = pd.DataFrame(dict_pred, index=[1, ])
        predict = model.predict(data_df)

        if predict[0]==0:
            result = 'Not servived'
        else:
            result = 'Servived'

        return result



if __name__=="__main__":
    host = '0.0.0.0'
    port = 5000
    app.run(debug=True)